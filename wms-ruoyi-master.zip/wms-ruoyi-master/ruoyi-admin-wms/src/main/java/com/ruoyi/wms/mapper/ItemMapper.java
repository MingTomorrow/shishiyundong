package com.ruoyi.wms.mapper;

import com.ruoyi.common.mybatis.core.mapper.BaseMapperPlus;
import com.ruoyi.wms.domain.entity.Item;
import com.ruoyi.wms.domain.vo.ItemVo;

public interface ItemMapper extends BaseMapperPlus<Item, ItemVo> {

}
