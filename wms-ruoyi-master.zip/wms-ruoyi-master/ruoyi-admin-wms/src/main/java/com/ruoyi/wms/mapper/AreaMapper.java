package com.ruoyi.wms.mapper;

import com.ruoyi.common.mybatis.core.mapper.BaseMapperPlus;
import com.ruoyi.wms.domain.vo.AreaVo;
import com.ruoyi.wms.domain.entity.Area;

public interface AreaMapper extends BaseMapperPlus<Area, AreaVo> {
}
