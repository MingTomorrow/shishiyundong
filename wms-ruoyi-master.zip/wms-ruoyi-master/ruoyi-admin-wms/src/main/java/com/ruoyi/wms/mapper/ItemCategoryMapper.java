package com.ruoyi.wms.mapper;

import com.ruoyi.common.mybatis.core.mapper.BaseMapperPlus;
import com.ruoyi.wms.domain.entity.ItemCategory;
import com.ruoyi.wms.domain.vo.ItemCategoryVo;

public interface ItemCategoryMapper extends BaseMapperPlus<ItemCategory, ItemCategoryVo> {
}
