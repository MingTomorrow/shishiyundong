package com.ruoyi.common.sms.config;

/**
 * 短信配置类
 *
 *
 * @version 4.2.0
 */
//@Configuration // 暂时用不上 留着后续扩展使用
public class SmsConfig {

}
