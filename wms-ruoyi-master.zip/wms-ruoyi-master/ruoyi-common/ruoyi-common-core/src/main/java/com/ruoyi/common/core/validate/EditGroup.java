package com.ruoyi.common.core.validate;

/**
 * 校验分组 edit
 *
 *
 */
public interface EditGroup {
}
