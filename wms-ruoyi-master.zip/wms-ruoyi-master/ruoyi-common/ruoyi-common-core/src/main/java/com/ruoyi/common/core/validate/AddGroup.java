package com.ruoyi.common.core.validate;

/**
 * 校验分组 add
 *
 *
 */
public interface AddGroup {
}
